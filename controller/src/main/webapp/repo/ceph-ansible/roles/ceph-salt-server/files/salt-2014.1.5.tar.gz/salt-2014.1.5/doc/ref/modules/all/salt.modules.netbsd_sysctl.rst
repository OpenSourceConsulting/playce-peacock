==========================
salt.modules.netbsd_sysctl
==========================

.. automodule:: salt.modules.netbsd_sysctl
    :members: