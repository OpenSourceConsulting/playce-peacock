=================
salt.states.alias
=================

.. automodule:: salt.states.alias
    :members:
