==========================
salt.modules.netbsdservice
==========================

.. automodule:: salt.modules.netbsdservice
    :members: