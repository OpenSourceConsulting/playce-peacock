================
salt.states.xmpp
================

.. automodule:: salt.states.xmpp
    :members:
