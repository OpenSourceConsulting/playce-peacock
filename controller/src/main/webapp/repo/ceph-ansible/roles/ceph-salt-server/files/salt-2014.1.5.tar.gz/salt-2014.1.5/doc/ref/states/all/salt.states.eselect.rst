===================
salt.states.eselect
===================

.. automodule:: salt.states.eselect
    :members: