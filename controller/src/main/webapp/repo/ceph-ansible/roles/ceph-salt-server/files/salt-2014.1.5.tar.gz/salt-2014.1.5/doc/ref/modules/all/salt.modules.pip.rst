================
salt.modules.pip
================

.. automodule:: salt.modules.pip
    :members: