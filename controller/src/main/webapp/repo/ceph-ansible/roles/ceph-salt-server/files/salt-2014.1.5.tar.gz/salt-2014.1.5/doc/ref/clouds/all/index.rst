.. _all-salt.clouds:

===============================
Full list of Salt Cloud modules
===============================

.. currentmodule:: salt.cloud.clouds

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    botocore_aws
    cloudstack
    digital_ocean
    ec2
    gce
    gogrid
    ibmsce
    joyent
    libcloud_aws
    linode
    msazure
    nova
    openstack
    parallels
    rackspace
    saltify
    softlayer
