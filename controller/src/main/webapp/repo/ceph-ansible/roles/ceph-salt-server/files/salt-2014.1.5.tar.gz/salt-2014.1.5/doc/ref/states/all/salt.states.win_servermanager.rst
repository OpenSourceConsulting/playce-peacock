=============================
salt.states.win_servermanager
=============================

.. automodule:: salt.states.win_servermanager
    :members:
