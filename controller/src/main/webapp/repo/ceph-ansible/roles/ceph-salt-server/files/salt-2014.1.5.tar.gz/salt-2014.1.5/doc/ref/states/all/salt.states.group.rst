=================
salt.states.group
=================

.. automodule:: salt.states.group
    :members: