===================
salt.modules.pacman
===================

.. automodule:: salt.modules.pacman
    :members:
    :exclude-members: available_version
