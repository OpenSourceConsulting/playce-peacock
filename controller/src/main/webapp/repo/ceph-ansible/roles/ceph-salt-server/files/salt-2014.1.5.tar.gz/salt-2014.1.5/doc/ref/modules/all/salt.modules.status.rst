===================
salt.modules.status
===================

.. automodule:: salt.modules.status
    :members: