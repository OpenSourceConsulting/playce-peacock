=======================
salt.states.supervisord
=======================

.. automodule:: salt.states.supervisord
    :members: