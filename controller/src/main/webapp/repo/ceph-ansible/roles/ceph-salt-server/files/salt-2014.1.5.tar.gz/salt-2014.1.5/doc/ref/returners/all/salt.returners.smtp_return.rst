==========================
salt.returners.smtp_return
==========================

.. automodule:: salt.returners.smtp_return
    :members: