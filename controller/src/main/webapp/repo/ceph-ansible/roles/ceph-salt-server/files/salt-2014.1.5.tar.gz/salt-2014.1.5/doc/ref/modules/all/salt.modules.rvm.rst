================
salt.modules.rvm
================

.. automodule:: salt.modules.rvm
    :members: