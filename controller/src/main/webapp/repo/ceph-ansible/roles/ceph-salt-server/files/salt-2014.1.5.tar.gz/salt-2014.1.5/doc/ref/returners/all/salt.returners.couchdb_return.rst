=============================
salt.returners.couchdb_return
=============================

.. automodule:: salt.returners.couchdb_return
    :members: