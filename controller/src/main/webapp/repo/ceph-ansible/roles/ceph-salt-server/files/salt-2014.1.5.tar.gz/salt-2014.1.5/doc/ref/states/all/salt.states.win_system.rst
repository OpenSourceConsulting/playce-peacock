======================
salt.states.win_system
======================

.. automodule:: salt.states.win_system
    :members:
    :exclude-members: computer_description
