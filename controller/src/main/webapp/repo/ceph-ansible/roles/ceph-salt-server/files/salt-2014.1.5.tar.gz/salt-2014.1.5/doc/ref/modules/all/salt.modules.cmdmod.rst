===================
salt.modules.cmdmod
===================

.. automodule:: salt.modules.cmdmod
    :members:
