==================
salt.output.no_out
==================

.. automodule:: salt.output.no_out
    :members: