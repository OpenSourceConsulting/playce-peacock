===============
salt.states.git
===============

.. automodule:: salt.states.git
    :members:
