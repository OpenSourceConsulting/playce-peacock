====================
salt.modules.useradd
====================

.. automodule:: salt.modules.useradd
    :members: