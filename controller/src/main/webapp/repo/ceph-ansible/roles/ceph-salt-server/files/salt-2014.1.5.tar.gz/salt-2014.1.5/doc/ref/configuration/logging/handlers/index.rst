.. conf_log:: external-logging-handlers

External Logging Handlers
-------------------------

.. currentmodule:: salt.log.handlers

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    logstash_mod
    sentry_mod
