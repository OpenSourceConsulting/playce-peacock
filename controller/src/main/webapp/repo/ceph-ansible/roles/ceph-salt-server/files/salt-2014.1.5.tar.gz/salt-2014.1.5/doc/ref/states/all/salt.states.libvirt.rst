===================
salt.states.libvirt
===================

.. automodule:: salt.states.libvirt
    :members:
