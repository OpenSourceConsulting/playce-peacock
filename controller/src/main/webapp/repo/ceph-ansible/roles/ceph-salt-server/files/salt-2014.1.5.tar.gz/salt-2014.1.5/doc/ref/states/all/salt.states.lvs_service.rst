=======================
salt.states.lvs_service
=======================

.. automodule:: salt.states.lvs_service
    :members: