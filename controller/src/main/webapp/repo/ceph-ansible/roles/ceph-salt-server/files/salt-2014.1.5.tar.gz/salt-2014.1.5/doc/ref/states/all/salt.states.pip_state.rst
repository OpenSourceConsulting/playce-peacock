=====================
salt.states.pip_state
=====================

.. automodule:: salt.states.pip_state
    :members:
