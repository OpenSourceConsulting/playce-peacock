================
salt.states.disk
================

.. automodule:: salt.states.disk
    :members: