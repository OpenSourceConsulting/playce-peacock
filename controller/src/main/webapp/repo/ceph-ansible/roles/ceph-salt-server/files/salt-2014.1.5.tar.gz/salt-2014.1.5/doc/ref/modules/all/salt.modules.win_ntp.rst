====================
salt.modules.win_ntp
====================

.. automodule:: salt.modules.win_ntp
    :members:
