============================
salt.states.openstack_config
============================

.. automodule:: salt.states.openstack_config
    :members: