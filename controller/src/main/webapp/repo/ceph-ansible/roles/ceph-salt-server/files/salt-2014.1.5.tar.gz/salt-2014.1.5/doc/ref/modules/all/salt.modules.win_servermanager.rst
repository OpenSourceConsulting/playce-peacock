==============================
salt.modules.win_servermanager
==============================

.. automodule:: salt.modules.win_servermanager
    :members: