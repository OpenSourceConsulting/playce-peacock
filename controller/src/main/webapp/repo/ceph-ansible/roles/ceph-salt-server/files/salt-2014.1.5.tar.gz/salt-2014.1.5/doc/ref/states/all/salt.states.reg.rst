===============
salt.states.reg
===============

.. automodule:: salt.states.reg
    :members: