====================
salt.returners.local
====================

.. automodule:: salt.returners.local
    :members: