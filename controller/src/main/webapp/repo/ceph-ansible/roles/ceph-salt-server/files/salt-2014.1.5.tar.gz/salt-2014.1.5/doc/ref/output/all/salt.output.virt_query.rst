======================
salt.output.virt_query
======================

.. automodule:: salt.output.virt_query
    :members: