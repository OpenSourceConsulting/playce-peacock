===================
salt.pillar.virtkey
===================

.. automodule:: salt.pillar.virtkey
    :members: