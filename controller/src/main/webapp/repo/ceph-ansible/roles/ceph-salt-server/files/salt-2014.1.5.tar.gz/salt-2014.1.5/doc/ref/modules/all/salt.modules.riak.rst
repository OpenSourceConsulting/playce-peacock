=================
salt.modules.riak
=================

.. automodule:: salt.modules.riak
    :members: