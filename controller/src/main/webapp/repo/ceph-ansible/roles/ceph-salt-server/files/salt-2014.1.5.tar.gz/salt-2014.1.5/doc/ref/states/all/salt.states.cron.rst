================
salt.states.cron
================

.. automodule:: salt.states.cron
    :members: