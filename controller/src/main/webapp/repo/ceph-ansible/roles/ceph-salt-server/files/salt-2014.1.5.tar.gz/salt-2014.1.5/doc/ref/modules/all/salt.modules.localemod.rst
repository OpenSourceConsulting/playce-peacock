======================
salt.modules.localemod
======================

.. automodule:: salt.modules.localemod
    :members: