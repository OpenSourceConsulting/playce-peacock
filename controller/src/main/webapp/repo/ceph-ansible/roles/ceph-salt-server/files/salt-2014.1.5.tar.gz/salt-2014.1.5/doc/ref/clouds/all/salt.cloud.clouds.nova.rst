======================
salt.cloud.clouds.nova
======================

.. automodule:: salt.cloud.clouds.nova
    :members: