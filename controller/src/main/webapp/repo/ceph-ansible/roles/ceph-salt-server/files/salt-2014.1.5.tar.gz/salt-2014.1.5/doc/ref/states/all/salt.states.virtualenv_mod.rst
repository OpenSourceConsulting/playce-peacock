======================
salt.states.virtualenv
======================

.. automodule:: salt.states.virtualenv_mod
    :members:
    :exclude-members: manage
