===================
salt.runners.search
===================

.. automodule:: salt.runners.search
    :members: