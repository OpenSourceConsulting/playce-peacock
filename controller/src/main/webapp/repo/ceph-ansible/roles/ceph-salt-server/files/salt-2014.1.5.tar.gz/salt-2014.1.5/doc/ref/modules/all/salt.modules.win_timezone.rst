=========================
salt.modules.win_timezone
=========================

.. automodule:: salt.modules.win_timezone
    :members: