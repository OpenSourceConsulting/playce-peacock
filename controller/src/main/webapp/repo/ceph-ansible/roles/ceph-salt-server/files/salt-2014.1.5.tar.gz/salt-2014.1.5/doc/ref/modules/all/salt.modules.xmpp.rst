=================
salt.modules.xmpp
=================

.. automodule:: salt.modules.xmpp
    :members:
