===================
salt.states.selinux
===================

.. automodule:: salt.states.selinux
    :members:
