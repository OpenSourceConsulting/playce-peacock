========================
salt.modules.win_service
========================

.. automodule:: salt.modules.win_service
    :members: