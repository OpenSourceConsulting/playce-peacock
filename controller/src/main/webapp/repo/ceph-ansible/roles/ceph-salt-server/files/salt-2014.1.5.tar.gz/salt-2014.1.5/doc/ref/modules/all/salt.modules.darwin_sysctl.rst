==========================
salt.modules.darwin_sysctl
==========================

.. automodule:: salt.modules.darwin_sysctl
    :members: