===================
salt.pillar.cobbler
===================

.. automodule:: salt.pillar.cobbler
    :members:
