======================
salt.modules.poudriere
======================

.. automodule:: salt.modules.poudriere
    :members: