=========================
salt.modules.solaris_user
=========================

.. automodule:: salt.modules.solaris_user
    :members: