===============
salt.states.npm
===============

.. automodule:: salt.states.npm
    :members: