=====================
salt.modules.postgres
=====================

.. automodule:: salt.modules.postgres
    :members:
