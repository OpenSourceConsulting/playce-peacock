============================
salt.returners.syslog_return
============================

.. automodule:: salt.returners.syslog_return
    :members: