================
salt.states.pecl
================

.. automodule:: salt.states.pecl
    :members: