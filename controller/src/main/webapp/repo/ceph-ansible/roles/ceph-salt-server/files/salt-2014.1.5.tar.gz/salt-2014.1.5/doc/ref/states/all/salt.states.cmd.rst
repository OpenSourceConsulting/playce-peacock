===============
salt.states.cmd
===============

.. automodule:: salt.states.cmd
    :members:
    :exclude-members: watch
