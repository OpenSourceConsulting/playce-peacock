============================
salt.returners.carbon_return
============================

.. automodule:: salt.returners.carbon_return
    :members: