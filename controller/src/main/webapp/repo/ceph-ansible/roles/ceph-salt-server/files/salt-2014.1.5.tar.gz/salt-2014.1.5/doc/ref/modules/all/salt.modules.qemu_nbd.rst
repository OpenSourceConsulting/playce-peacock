=====================
salt.modules.qemu_nbd
=====================

.. automodule:: salt.modules.qemu_nbd
    :members: