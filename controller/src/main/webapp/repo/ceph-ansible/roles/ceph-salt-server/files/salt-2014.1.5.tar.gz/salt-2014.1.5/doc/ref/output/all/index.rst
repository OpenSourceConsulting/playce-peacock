.. _all-salt.output:

===================================
Full list of builtin output modules
===================================

.. currentmodule:: salt.output

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    grains
    highstate
    json_out
    key
    nested
    no_out
    no_return
    overstatestage
    pprint_out
    raw
    txt
    virt_query
    yaml_out
