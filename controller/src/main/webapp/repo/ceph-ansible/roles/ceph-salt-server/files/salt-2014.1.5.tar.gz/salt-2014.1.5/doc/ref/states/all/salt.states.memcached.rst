=====================
salt.states.memcached
=====================

.. automodule:: salt.states.memcached
    :members: