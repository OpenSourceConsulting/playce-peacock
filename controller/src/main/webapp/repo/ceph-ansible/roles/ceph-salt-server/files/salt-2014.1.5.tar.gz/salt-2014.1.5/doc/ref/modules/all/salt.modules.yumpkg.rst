===================
salt.modules.yumpkg
===================

.. automodule:: salt.modules.yumpkg
    :members:
    :exclude-members: available_version
