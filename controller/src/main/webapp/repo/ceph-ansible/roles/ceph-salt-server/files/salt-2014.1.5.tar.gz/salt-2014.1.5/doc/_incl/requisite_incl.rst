**Before continuing** make sure you have a working Salt installation by
following the :doc:`installation </topics/installation/index>` and the :doc:`configuration
</topics/configuration>` instructions.

.. admonition:: Stuck?

    There are many ways to :doc:`get help from the Salt community
    </topics/community>` including our
    `mailing list <https://groups.google.com/forum/#!forum/salt-users>`_
    and our `IRC channel <http://webchat.freenode.net/?channels=salt>`_ #salt.
