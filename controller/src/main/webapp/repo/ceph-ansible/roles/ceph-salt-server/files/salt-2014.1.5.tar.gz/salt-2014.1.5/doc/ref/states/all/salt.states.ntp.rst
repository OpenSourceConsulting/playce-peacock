===============
salt.states.ntp
===============

.. automodule:: salt.states.ntp
    :members: