=======================
salt.modules.win_shadow
=======================

.. automodule:: salt.modules.win_shadow
    :members: